# Homey Pro Verisure France

Intégrez votre alarme Verisure France dans Homey Pro.

## ⚠️ Avertissement

CETTE APPLICATION N'EST EN AUCUN CAS ASSOCIÉE OU LIÉE AUX SOCIÉTÉS DU GROUPE SECURITAS DIRECT - VERISURE.
Usage strictement personnel et privé. Aucun support officiel.

## Compatibilité

- Verisure France uniquement
- Testé sur centrale SDVFAST
- Homey Pro SDK 3 (>= 12.0.0)

## Fonctionnalités

- Connexion MFA (email + code SMS)
- 4 modes d'alarme : Partiel Jour, Partiel Nuit, Mode Total, Désactivée
- Polling automatique toutes les 30 minutes
- Journal d'activité Verisure (ACT_V2)
- Flows Homey : triggers, conditions et actions sur l'état de l'alarme

## Installation

1. `homey app install`
2. Ouvrir les Réglages de l'application
3. Se connecter avec un compte Verisure dédié
4. Appairer la centrale depuis Appareils → Ajouter

## Source

https://github.com/ediverchy/com.verisurefr

## Développement

Vibe Coding — Co-auteurs : Etienne Diverchy & IA Claude (Anthropic)
